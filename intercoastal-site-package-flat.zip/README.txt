INTERCOASTAL OUTDOOR EQUIPMENT - VERCEL UPLOAD PACKAGE

This is a ready-to-upload React + Vite website package.

WHAT TO DO NEXT
1. Download and unzip this package.
2. In Vercel, click Add New Project.
3. Choose Import -> Upload.
4. Upload the unzipped project folder.
5. Vercel should detect Vite automatically.
6. Click Deploy.

BUILD SETTINGS
Framework Preset: Vite
Build Command: npm run build
Output Directory: dist
Install Command: npm install

FILES TO UPDATE LATER
- Phone number is still a placeholder in src/App.jsx
- Email address can be updated in src/App.jsx
- Service form is visual only right now and is not connected to email yet

DOMAIN CONNECTION
After the site deploys, add your GoDaddy domain inside Vercel:
Project -> Settings -> Domains -> Add Domain
Then follow the DNS prompts in Vercel.
